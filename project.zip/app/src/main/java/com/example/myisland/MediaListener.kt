package com.example.myisland

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class MediaListener : NotificationListenerService() {
    private var msm: MediaSessionManager? = null
    private var current: MediaController? = null
    private val ui = Handler(Looper.getMainLooper())

    private val cb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) { push() }
        override fun onMetadataChanged(metadata: MediaMetadata?) { push() }
    }

    private val sessionsChanged =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }

    override fun onListenerConnected() {
        super.onListenerConnected()
        val m = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        msm = m
        val me = ComponentName(this, MediaListener::class.java)
        try {
            m.addOnActiveSessionsChangedListener(sessionsChanged, me)
            pick(m.getActiveSessions(me))
        } catch (e: SecurityException) {
        }
    }

    override fun onListenerDisconnected() {
        try { msm?.removeOnActiveSessionsChangedListener(sessionsChanged) } catch (e: Exception) {}
        current?.unregisterCallback(cb)
        current = null
        super.onListenerDisconnected()
    }

    private fun pick(list: List<MediaController>?) {
        current?.unregisterCallback(cb)
        val c = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()
        current = c
        c?.registerCallback(cb)
        push()
    }

    private fun push() {
        val c = current
        Hub.controller = c
        val md = c?.metadata
        Hub.title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
        Hub.artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        Hub.playing = c?.playbackState?.state == PlaybackState.STATE_PLAYING
        Hub.onChange?.invoke()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val s = sbn ?: return
        if (s.packageName == packageName) return
        val n = s.notification
        if ((n.flags and Notification.FLAG_ONGOING_EVENT) != 0) return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if (n.category == Notification.CATEGORY_TRANSPORT) return
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val app = try {
            packageManager.getApplicationLabel(
                packageManager.getApplicationInfo(s.packageName, 0)
            ).toString()
        } catch (e: Exception) {
            s.packageName
        }
        Hub.notifApp = app
        Hub.notifTitle = title
        Hub.notifText = text
        ui.post { Hub.onNotif?.invoke() }
    }
}
