package com.example.myisland

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    class App(val label: String, val pkg: String, val intent: Intent, val icon: Drawable)

    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT
    private var apps: List<App> = emptyList()
    private var d = 1f
    private var pageCount = 1
    private lateinit var pager: Pager
    private lateinit var dots: LinearLayout
    private lateinit var spot: FrameLayout
    private lateinit var input: EditText
    private lateinit var results: LinearLayout

    private fun dp(v: Int) = (v * d).toInt()

    private fun statusBar(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(28)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        d = resources.displayMetrics.density
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        build()
    }

    private fun launcherQuery() = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)

    private fun loadApps(): List<App> {
        val pm = packageManager
        return pm.queryIntentActivities(launcherQuery(), 0).map { ri ->
            val pkg = ri.activityInfo.packageName
            App(
                ri.loadLabel(pm).toString(), pkg,
                launcherQuery()
                    .setClassName(pkg, ri.activityInfo.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED),
                ri.loadIcon(pm)
            )
        }.sortedBy { it.label.lowercase() }
    }

    private fun dockApps(): List<App> {
        val pm = packageManager
        val tries = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_BROWSER),
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        )
        val out = mutableListOf<App>()
        for (t in tries) {
            val p = pm.resolveActivity(t, 0)?.activityInfo?.packageName
            val a = apps.firstOrNull { it.pkg == p }
            if (a != null && a !in out) out.add(a)
        }
        return out
    }

    private fun iconView(a: App, size: Int): ImageView {
        return ImageView(this).apply {
            setImageDrawable(a.icon)
            layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, view.width * 0.23f)
                }
            }
        }
    }

    private fun launch(a: App) {
        try {
            startActivity(a.intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open", Toast.LENGTH_SHORT).show()
        }
    }

    private fun menu(v: View, a: App) {
        val p = PopupMenu(this, v)
        p.menu.add(0, 1, 0, "App info")
        p.menu.add(0, 2, 1, "Uninstall")
        p.setOnMenuItemClickListener { m ->
            val u = Uri.parse("package:" + a.pkg)
            if (m.itemId == 1) {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, u))
            } else {
                startActivity(Intent(Intent.ACTION_DELETE, u))
            }
            true
        }
        p.show()
    }

    private fun cell(a: App): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, MP, 1f)
            addView(iconView(a, 58))
            addView(TextView(this@MainActivity).apply {
                text = a.label
                textSize = 11f
                setTextColor(Color.WHITE)
                maxLines = 1
                gravity = Gravity.CENTER
                ellipsize = TextUtils.TruncateAt.END
                setPadding(dp(2), dp(4), dp(2), 0)
                setShadowLayer(6f, 0f, 1f, 0xAA000000.toInt())
            })
            setOnClickListener { launch(a) }
            setOnLongClickListener { menu(this, a); true }
        }
    }

    private fun buildPages(list: List<App>): LinearLayout {
        val per = 20
        pageCount = maxOf(1, (list.size + per - 1) / per)
        val w = resources.displayMetrics.widthPixels
        val strip = LinearLayout(this)
        strip.orientation = LinearLayout.HORIZONTAL
        for (p in 0 until pageCount) {
            val page = LinearLayout(this)
            page.orientation = LinearLayout.VERTICAL
            page.layoutParams = LinearLayout.LayoutParams(w, MP)
            page.setPadding(dp(8), dp(8), dp(8), dp(8))
            for (r in 0 until 5) {
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.layoutParams = LinearLayout.LayoutParams(MP, 0, 1f)
                for (c in 0 until 4) {
                    val i = p * per + r * 4 + c
                    if (i < list.size) {
                        row.addView(cell(list[i]))
                    } else {
                        val empty = View(this)
                        empty.layoutParams = LinearLayout.LayoutParams(0, MP, 1f)
                        row.addView(empty)
                    }
                }
                page.addView(row)
            }
            strip.addView(page)
        }
        return strip
    }

    private fun build() {
        apps = loadApps()
        val dockList = dockApps()
        val grid = apps.filter { it !in dockList }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(0, statusBar() + dp(6), 0, dp(10))

        pager = Pager(this)
        pager.isHorizontalScrollBarEnabled = false
        pager.overScrollMode = View.OVER_SCROLL_NEVER
        pager.layoutParams = LinearLayout.LayoutParams(MP, 0, 1f)
        pager.addView(buildPages(grid))

        dots = LinearLayout(this)
        dots.gravity = Gravity.CENTER
        for (i in 0 until pageCount) {
            val t = TextView(this)
            t.text = "●"
            t.textSize = 8f
            t.setTextColor(Color.WHITE)
            t.setPadding(dp(4), 0, dp(4), 0)
            dots.addView(t)
        }
        setDot(0)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER
        val barBg = GradientDrawable()
        barBg.setColor(0x40FFFFFF)
        barBg.cornerRadius = dp(30).toFloat()
        bar.background = barBg
        bar.setPadding(dp(10), dp(12), dp(10), dp(12))
        for (a in dockList) {
            val holder = LinearLayout(this)
            holder.gravity = Gravity.CENTER
            holder.layoutParams = LinearLayout.LayoutParams(0, WC, 1f)
            holder.addView(iconView(a, 58))
            holder.setOnClickListener { launch(a) }
            holder.setOnLongClickListener { menu(holder, a); true }
            bar.addView(holder)
        }
        val barLp = LinearLayout.LayoutParams(MP, WC)
        barLp.setMargins(dp(12), dp(8), dp(12), 0)

        root.addView(pager)
        root.addView(dots)
        root.addView(bar, barLp)

        buildSpot()
        val frame = FrameLayout(this)
        frame.addView(root, FrameLayout.LayoutParams(MP, MP))
        frame.addView(spot, FrameLayout.LayoutParams(MP, MP))
        setContentView(frame)
    }

    private fun setDot(p: Int) {
        for (i in 0 until dots.childCount) {
            dots.getChildAt(i).alpha = if (i == p) 1f else 0.35f
        }
    }

    inner class Pager(c: Context) : HorizontalScrollView(c) {
        private var startX = 0
        private var downX = 0f
        private var downY = 0f

        override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                startX = scrollX
                downX = ev.x
                downY = ev.y
            }
            val r = super.dispatchTouchEvent(ev)
            val up = ev.actionMasked == MotionEvent.ACTION_UP
            if (up || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                val w = width
                if (w > 0) {
                    val dx = scrollX - startX
                    var p = Math.round(startX / w.toFloat())
                    if (dx > w / 8) {
                        p += 1
                    } else if (dx < -w / 8) {
                        p -= 1
                    }
                    p = p.coerceIn(0, pageCount - 1)
                    smoothScrollTo(p * w, 0)
                    setDot(p)
                }
                if (up && ev.y - downY > dp(110) && Math.abs(ev.x - downX) < dp(80)) {
                    openSpot()
                }
            }
            return r
        }
    }

    private fun buildSpot() {
        input = EditText(this)
        input.hint = "Search apps"
        input.setHintTextColor(0xFF8E8E93.toInt())
        input.setTextColor(Color.WHITE)
        input.textSize = 17f
        input.setSingleLine(true)
        val ib = GradientDrawable()
        ib.setColor(0xFF2C2C2E.toInt())
        ib.cornerRadius = dp(14).toFloat()
        input.background = ib
        input.setPadding(dp(14), dp(10), dp(14), dp(10))

        results = LinearLayout(this)
        results.orientation = LinearLayout.VERTICAL

        val sv = ScrollView(this)
        sv.addView(results)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), statusBar() + dp(16), dp(16), dp(16))
        box.addView(input)
        box.addView(sv)

        spot = FrameLayout(this)
        spot.setBackgroundColor(0xDD000000.toInt())
        spot.visibility = View.GONE
        spot.isClickable = true
        spot.addView(box, FrameLayout.LayoutParams(MP, MP))

        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { search(s?.toString() ?: "") }
        })
    }

    private fun search(q: String) {
        results.removeAllViews()
        if (q.isBlank()) return
        for (a in apps.filter { it.label.contains(q, ignoreCase = true) }.take(8)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, dp(8), 0, dp(8))
            row.addView(iconView(a, 44))
            val t = TextView(this)
            t.text = a.label
            t.textSize = 17f
            t.setTextColor(Color.WHITE)
            t.setPadding(dp(14), 0, 0, 0)
            row.addView(t)
            row.setOnClickListener { closeSpot(); launch(a) }
            results.addView(row)
        }
    }

    private fun openSpot() {
        spot.visibility = View.VISIBLE
        input.setText("")
        input.requestFocus()
        input.postDelayed({
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(input, 0)
        }, 150)
    }

    private fun closeSpot() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(input.windowToken, 0)
        spot.visibility = View.GONE
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (spot.visibility == View.VISIBLE) closeSpot()
        pager.smoothScrollTo(0, 0)
        setDot(0)
    }

    override fun onBackPressed() {
        if (spot.visibility == View.VISIBLE) closeSpot()
    }

    override fun onResume() {
        super.onResume()
        if (packageManager.queryIntentActivities(launcherQuery(), 0).size != apps.size) build()
    }
}
