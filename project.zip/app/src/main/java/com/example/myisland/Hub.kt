package com.example.myisland

import android.media.session.MediaController

object Hub {
    var controller: MediaController? = null
    var title: String = ""
    var artist: String = ""
    var playing: Boolean = false
    var notifApp: String = ""
    var notifTitle: String = ""
    var notifText: String = ""
    var onChange: (() -> Unit)? = null
    var onNotif: (() -> Unit)? = null
}
