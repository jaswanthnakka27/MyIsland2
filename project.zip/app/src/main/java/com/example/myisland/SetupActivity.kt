package com.example.myisland

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class SetupActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding((20 * d).toInt(), (48 * d).toInt(), (20 * d).toInt(), (20 * d).toInt())
        val title = TextView(this)
        title.text = "MyIsland setup\nDo steps 1 to 4, then press Home."
        title.textSize = 18f
        col.addView(title)

        fun step(label: String, i: Intent) {
            val btn = Button(this)
            btn.text = label
            btn.setOnClickListener {
                try { startActivity(i) } catch (e: Exception) {}
            }
            col.addView(btn)
        }

        val me = Uri.parse("package:" + packageName)
        step("1. Enable Island (Accessibility)", Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        step("2. Enable Notification access", Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        step("3. Allow brightness control", Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, me))
        step("4. Set MyIsland as Home app", Intent(Settings.ACTION_HOME_SETTINGS))
        step("Switch greyed out? Open App info", Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, me))

        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)
    }
}
