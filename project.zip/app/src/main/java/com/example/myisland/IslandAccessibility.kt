package com.example.myisland

import android.accessibilityservice.AccessibilityService
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class IslandAccessibility : AccessibilityService() {

    private val topMargin = 10 // raise or lower the pill (in dp) to line up with your camera

    private lateinit var wm: WindowManager
    private var d = 1f
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var island: LinearLayout
    private lateinit var islandLp: WindowManager.LayoutParams
    private lateinit var bg: GradientDrawable
    private lateinit var tvTop: TextView
    private lateinit var tvMid: TextView
    private lateinit var tvSub: TextView
    private lateinit var controls: LinearLayout
    private var anim: ValueAnimator? = null
    private var mode = 0 // 0 idle, 1 notification, 2 music, 3 clock
    private var lastTitle = ""
    private val collapseRun = Runnable { collapse() }

    private var hotL: View? = null
    private var hotR: View? = null
    private var ccView: View? = null
    private var torchOn = false

    private fun dp(v: Int) = (v * d).toInt()

    private fun statusBarH(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(28)
    }

    private fun overlayParams(w: Int, h: Int): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        if (::island.isInitialized) return
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        d = resources.displayMetrics.density
        buildIsland()
        hotL = hotspot(Gravity.START) { performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS) }
        hotR = hotspot(Gravity.END) { showControl() }
        Hub.onChange = { onMedia() }
        Hub.onNotif = { expand(1, 4500) }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        Hub.onChange = null
        Hub.onNotif = null
        ui.removeCallbacksAndMessages(null)
        if (::wm.isInitialized) {
            val views = mutableListOf<View?>(hotL, hotR, ccView)
            if (::island.isInitialized) views.add(island)
            for (v in views) {
                if (v != null) {
                    try { wm.removeView(v) } catch (e: Exception) {}
                }
            }
        }
        super.onDestroy()
    }

    // ---------- Dynamic Island ----------

    private fun btn(label: String, act: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = 24f
        t.setTextColor(Color.WHITE)
        t.setPadding(dp(24), dp(2), dp(24), dp(2))
        t.setOnClickListener { act() }
        return t
    }

    private fun playPause() {
        val tc = Hub.controller?.transportControls
        if (Hub.playing) tc?.pause() else tc?.play()
    }

    private fun buildIsland() {
        bg = GradientDrawable()
        bg.setColor(Color.BLACK)
        bg.cornerRadius = dp(100).toFloat()

        tvTop = TextView(this)
        tvTop.setTextColor(0xFF8E8E93.toInt())
        tvTop.textSize = 11f
        tvTop.maxLines = 1

        tvMid = TextView(this)
        tvMid.setTextColor(Color.WHITE)
        tvMid.textSize = 16f
        tvMid.typeface = Typeface.DEFAULT_BOLD
        tvMid.maxLines = 1
        tvMid.ellipsize = TextUtils.TruncateAt.END

        tvSub = TextView(this)
        tvSub.setTextColor(0xFFB0B0B5.toInt())
        tvSub.textSize = 13f
        tvSub.maxLines = 1
        tvSub.ellipsize = TextUtils.TruncateAt.END

        controls = LinearLayout(this)
        controls.orientation = LinearLayout.HORIZONTAL
        controls.gravity = Gravity.CENTER
        controls.addView(btn("⏮") { Hub.controller?.transportControls?.skipToPrevious() })
        controls.addView(btn("⏯") { playPause() })
        controls.addView(btn("⏭") { Hub.controller?.transportControls?.skipToNext() })

        island = LinearLayout(this)
        island.orientation = LinearLayout.VERTICAL
        island.gravity = Gravity.CENTER
        island.background = bg
        island.setPadding(dp(18), dp(6), dp(18), dp(6))
        island.addView(tvTop)
        island.addView(tvMid)
        island.addView(tvSub)
        island.addView(controls)
        island.setOnClickListener { onTap() }
        hideAll()

        islandLp = overlayParams(dp(126), dp(36))
        islandLp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        islandLp.y = dp(topMargin)
        wm.addView(island, islandLp)
    }

    private fun hideAll() {
        tvTop.visibility = View.GONE
        tvMid.visibility = View.GONE
        tvSub.visibility = View.GONE
        controls.visibility = View.GONE
    }

    private fun fill(top: String, mid: String, sub: String, ctrl: Boolean) {
        tvTop.text = top
        tvMid.text = mid
        tvSub.text = sub
        tvTop.visibility = View.VISIBLE
        tvMid.visibility = View.VISIBLE
        tvSub.visibility = if (sub.isEmpty()) View.GONE else View.VISIBLE
        controls.visibility = if (ctrl) View.VISIBLE else View.GONE
    }

    private fun battery(): String {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return ""
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val chg = st == BatteryManager.BATTERY_STATUS_CHARGING ||
            st == BatteryManager.BATTERY_STATUS_FULL
        val pct = if (sc > 0) lvl * 100 / sc else 0
        return pct.toString() + "%" + (if (chg) " ⚡" else "")
    }

    private fun onTap() {
        if (mode != 0) {
            collapse()
        } else if (Hub.title.isNotEmpty()) {
            expand(2, 8000)
        } else {
            expand(3, 3500)
        }
    }

    private fun onMedia() {
        val changed = Hub.title != lastTitle
        lastTitle = Hub.title
        if (mode == 2) {
            expand(2, 8000)
        } else if (mode == 0 && changed && Hub.playing && Hub.title.isNotEmpty()) {
            expand(2, 4000)
        }
    }

    private fun expand(m: Int, ms: Long) {
        ui.removeCallbacks(collapseRun)
        mode = m
        when (m) {
            1 -> {
                fill(Hub.notifApp, Hub.notifTitle, Hub.notifText, false)
                morph(dp(350), dp(94))
            }
            2 -> {
                fill(
                    if (Hub.playing) "Now playing" else "Paused",
                    if (Hub.title.isEmpty()) "Nothing playing" else Hub.title,
                    Hub.artist, true
                )
                morph(dp(350), dp(142))
            }
            else -> {
                val now = Date()
                fill(
                    SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(now),
                    SimpleDateFormat("h:mm a", Locale.getDefault()).format(now) + "  •  " + battery(),
                    "", false
                )
                morph(dp(300), dp(84))
            }
        }
        ui.postDelayed(collapseRun, ms)
    }

    private fun collapse() {
        ui.removeCallbacks(collapseRun)
        mode = 0
        hideAll()
        morph(dp(126), dp(36))
    }

    private fun morph(w: Int, hgt: Int) {
        anim?.cancel()
        val w0 = islandLp.width
        val h0 = islandLp.height
        val grow = w > w0 || hgt > h0
        val va = ValueAnimator.ofFloat(0f, 1f)
        va.duration = 320L
        va.interpolator = OvershootInterpolator(0.6f)
        va.addUpdateListener {
            val t = it.animatedValue as Float
            islandLp.width = (w0 + (w - w0) * t).toInt()
            islandLp.height = (h0 + (hgt - h0) * t).toInt()
            bg.cornerRadius = minOf(islandLp.height / 2f, dp(32).toFloat())
            if (grow) {
                val a = ((t - 0.4f) / 0.6f).coerceIn(0f, 1f)
                tvTop.alpha = a
                tvMid.alpha = a
                tvSub.alpha = a
                controls.alpha = a
            }
            try { wm.updateViewLayout(island, islandLp) } catch (e: Exception) {}
        }
        anim = va
        va.start()
    }

    // ---------- Corner swipes ----------

    private fun hotspot(side: Int, onSwipe: () -> Unit): View {
        val v = View(this)
        var y0 = 0f
        v.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                y0 = e.rawY
            } else if (e.actionMasked == MotionEvent.ACTION_MOVE && y0 >= 0f && e.rawY - y0 > dp(36)) {
                y0 = -1f
                onSwipe()
            }
            true
        }
        val lp = overlayParams(dp(110), statusBarH())
        lp.gravity = Gravity.TOP or side
        wm.addView(v, lp)
        return v
    }

    // ---------- Control Center ----------

    private fun go(action: String) {
        hideControl()
        try {
            startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
        }
    }

    private fun tile(emoji: String, label: String, tap: (TextView) -> Unit): LinearLayout {
        val circle = TextView(this)
        circle.text = emoji
        circle.textSize = 22f
        circle.gravity = Gravity.CENTER
        val cb = GradientDrawable()
        cb.shape = GradientDrawable.OVAL
        cb.setColor(0xFF48484A.toInt())
        circle.background = cb
        circle.layoutParams = LinearLayout.LayoutParams(dp(58), dp(58))
        circle.setOnClickListener { tap(circle) }

        val lab = TextView(this)
        lab.text = label
        lab.textSize = 11f
        lab.setTextColor(Color.WHITE)
        lab.gravity = Gravity.CENTER
        lab.setPadding(0, dp(4), 0, 0)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        col.addView(circle)
        col.addView(lab)
        return col
    }

    private fun toggleTorch(c: TextView) {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            var id: String? = null
            for (x in cm.cameraIdList) {
                if (cm.getCameraCharacteristics(x).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) {
                    id = x
                    break
                }
            }
            if (id == null) return
            cm.setTorchMode(id, !torchOn)
            torchOn = !torchOn
            (c.background as GradientDrawable)
                .setColor(if (torchOn) 0xFFFFD60A.toInt() else 0xFF48484A.toInt())
        } catch (e: Exception) {
        }
    }

    private fun slider(
        emoji: String, maxV: Int, start: Int,
        onStart: () -> Unit, onChange: (Int) -> Unit
    ): LinearLayout {
        val sb = SeekBar(this)
        sb.max = maxV
        sb.progress = start
        sb.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) onChange(p)
            }
            override fun onStartTrackingTouch(s: SeekBar?) { onStart() }
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val icon = TextView(this)
        icon.text = emoji
        icon.textSize = 20f
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(14), 0, 0)
        row.addView(icon)
        row.addView(sb)
        return row
    }

    private fun showControl() {
        if (ccView != null) return

        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        val pb = GradientDrawable()
        pb.setColor(0xF01C1C1E.toInt())
        pb.cornerRadius = dp(32).toFloat()
        panel.background = pb
        panel.setPadding(dp(16), dp(18), dp(16), dp(18))
        panel.isClickable = true

        val row1 = LinearLayout(this)
        row1.orientation = LinearLayout.HORIZONTAL
        row1.addView(tile("📶", "Internet") {
            go(if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY
            else Settings.ACTION_WIFI_SETTINGS)
        })
        row1.addView(tile("🔵", "Bluetooth") { go(Settings.ACTION_BLUETOOTH_SETTINGS) })
        row1.addView(tile("✈️", "Airplane") { go(Settings.ACTION_AIRPLANE_MODE_SETTINGS) })
        row1.addView(tile("🔦", "Torch") { c -> toggleTorch(c) })
        panel.addView(row1)

        val cur = try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS)
        } catch (e: Exception) {
            128
        }
        panel.addView(slider("☀️", 255, cur, {
            if (!Settings.System.canWrite(this)) {
                hideControl()
                val i = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + packageName))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { startActivity(i) } catch (e: Exception) {}
            }
        }, { p ->
            try {
                Settings.System.putInt(
                    contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                )
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, p)
            } catch (e: Exception) {
            }
        }))

        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        panel.addView(slider(
            "🔊",
            am.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
            am.getStreamVolume(AudioManager.STREAM_MUSIC),
            {},
            { p -> am.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0) }
        ))

        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL
        row2.setPadding(0, dp(18), 0, 0)
        row2.addView(tile("⚙️", "Settings") { go(Settings.ACTION_SETTINGS) })
        row2.addView(tile("🔒", "Lock") {
            hideControl()
            if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        })
        row2.addView(tile("📸", "Screenshot") {
            hideControl()
            ui.postDelayed({
                if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
            }, 400)
        })
        row2.addView(tile("🗂️", "Recents") {
            hideControl()
            performGlobalAction(GLOBAL_ACTION_RECENTS)
        })
        panel.addView(row2)

        val root = FrameLayout(this)
        root.setBackgroundColor(0x88000000.toInt())
        root.setOnClickListener { hideControl() }
        val plp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT
        )
        plp.setMargins(dp(14), statusBarH() + dp(12), dp(14), 0)
        root.addView(panel, plp)

        wm.addView(root, overlayParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
        ))
        ccView = root
        root.alpha = 0f
        root.animate().alpha(1f).setDuration(200).start()
        panel.translationY = -dp(500).toFloat()
        panel.animate().translationY(0f).setDuration(260).start()
    }

    private fun hideControl() {
        val v = ccView ?: return
        ccView = null
        v.animate().alpha(0f).setDuration(180).withEndAction {
            try { wm.removeView(v) } catch (e: Exception) {}
        }.start()
    }
}
